package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputLayout;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TreeDataPreviewActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    Tree tree;
    ImageView iV;
    EditText etType, etPrice, etUrl;
    Button btnPlant, btnSeeMap, btnUpdateData, btnSaveData, btnCancelSave;
    String type = "", imageUrl = "";
    double price;
    boolean valid = true;
    TextInputLayout textInputLayout;
    AutoCompleteTextView autoCompleteTextView;

    public DrawerLayout drawerLayout;
    public NavigationView navigationView;
    public Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tree_data_preview_activity);

        drawerLayout = findViewById(R.id.drawerLayoutTreeDataPreview);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbarTreeDataPreview);
        setSupportActionBar(toolbar);

        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        initButtons();
        initEditTexts();
        initImageViews();
        initTextInput();
        findTree();

        if (!Users.loggedOnUser.isAdmin()) {
            btnUpdateData.setVisibility(View.GONE);
        }
    }

    void initButtons() {
        btnPlant = findViewById(R.id.btnPlant);
        btnSeeMap = findViewById(R.id.btnSeeMap);
        btnUpdateData = findViewById(R.id.btnUpdateTreeData);
        btnSaveData = findViewById(R.id.btnSaveTreeData);
        btnCancelSave = findViewById(R.id.btnCancelUpdateTree);
        btnPlant.setOnClickListener(this);
        btnSeeMap.setOnClickListener(this);
        btnUpdateData.setOnClickListener(this);
        btnSaveData.setOnClickListener(this);
        btnCancelSave.setOnClickListener(this);

        btnSaveData.setVisibility(View.GONE);
        btnCancelSave.setVisibility(View.GONE);
    }

    void initTextInput() {
        textInputLayout = findViewById(R.id.inputLayout);
        autoCompleteTextView = findViewById(R.id.inputTV);

        List<String> addresses = Locations.getAddressesOnly();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_drop_down, addresses);
        autoCompleteTextView.setAdapter(adapter);
        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Locations.setChosenLocation(Locations.getLocationByAddress(addresses.get(position)));
                textInputLayout.setError("");
            }
        });
    }

    void initImageViews() {
        iV = findViewById(R.id.iVTree);
    }

    void initEditTexts() {
        etType = findViewById(R.id.etTypeOfTree);
        etPrice = findViewById(R.id.etPriceOfTree);
        etUrl = findViewById(R.id.etImageUrlOfTree);

        etUrl.setText(Trees.chosenTree.getImageUrl());
        etType.setInputType(InputType.TYPE_NULL);
        etPrice.setInputType(InputType.TYPE_NULL);
        etUrl.setVisibility(View.GONE);
    }

    @SuppressLint("SetTextI18n")
    public void findTree() {
        Intent intent = getIntent();
        String type = intent.getStringExtra("type");
        tree = Trees.getTreeByType(type);
        Picasso.get().load(tree.getImageUrl()).into(iV);
        etType.setText(tree.getType());
        etPrice.setText((tree.getPrice() + "₪"));
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.nav_home){
            Intent intent = new Intent(TreeDataPreviewActivity.this, HomeActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_new_tree_plant) {
            Intent intent = new Intent(TreeDataPreviewActivity.this, TreesListActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_planted_trees) {
            if (Users.loggedOnUser.isAdmin()) {
                Intent intent = new Intent(TreeDataPreviewActivity.this, PlantsHistoryAdminActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(TreeDataPreviewActivity.this, PlantsHistoryUserActivity.class);
                startActivity(intent);
            }
        }
        if (menuItem.getItemId() == R.id.nav_account_center) {
            Intent intent = new Intent(TreeDataPreviewActivity.this, InfoUpdateActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_log_out){
            LogoutDialogBoxActivity logoutDialogBoxActivity = new LogoutDialogBoxActivity(this);
            logoutDialogBoxActivity.show();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {

        if (btnUpdateData.isPressed()) {
            etType.setInputType(InputType.TYPE_CLASS_TEXT);
            etPrice.setInputType(InputType.TYPE_CLASS_TEXT);
            etPrice.setInputType(InputType.TYPE_CLASS_TEXT);
            btnUpdateData.setVisibility(View.GONE);
            btnPlant.setVisibility(View.GONE);
            btnSeeMap.setVisibility(View.GONE);
            textInputLayout.setVisibility(View.GONE);
            btnSaveData.setVisibility(View.VISIBLE);
            btnCancelSave.setVisibility(View.VISIBLE);
            etUrl.setVisibility(View.VISIBLE);

            etType.setText(tree.getType());
            etPrice.setText((tree.getPrice() + "₪"));
            etUrl.setText(Trees.chosenTree.getImageUrl());
            textInputLayout.setError("");
        }

        if (btnCancelSave.isPressed()) {
            etType.setInputType(InputType.TYPE_NULL);
            etPrice.setInputType(InputType.TYPE_NULL);
            etUrl.setVisibility(View.GONE);
            btnSaveData.setVisibility(View.GONE);
            btnCancelSave.setVisibility(View.GONE);
            btnSeeMap.setVisibility(View.VISIBLE);
            textInputLayout.setVisibility(View.VISIBLE);
            btnPlant.setVisibility(View.VISIBLE);
            btnUpdateData.setVisibility(View.VISIBLE);

            etType.setText(tree.getType());
            etPrice.setText((tree.getPrice() + "₪"));
            etUrl.setText(Trees.chosenTree.getImageUrl());
            textInputLayout.setError("");
        }

        if (btnSaveData.isPressed()) {
            if (etType.getText().toString().isEmpty()) {
                etType.setError("Invalid Type");
                valid = false;
            }
            if (etPrice.getText().toString().isEmpty() || etPrice.getText().toString().contains("₪")) {
                etPrice.setError("Invalid Price");
                valid = false;
            }
            if (etUrl.getText().toString().isEmpty()) {
                etPrice.setError("Invalid URL");
                valid = false;
            }

            type = etType.getText().toString();
            price = Double.parseDouble(etPrice.getText().toString());
            imageUrl = etUrl.getText().toString();
            int chosenTreeID = Trees.chosenTree.getID();

            if (valid) {
                @SuppressLint("DefaultLocale")
                String updateTree = String.format("UPDATE trees SET " +
                                "type = COALESCE('%s', type)," +
                                "price = COALESCE(%f, price)," +
                                "imageUrl = '%s', imageUrl" +
                                "WHERE id = %d",
                        type, price, imageUrl, chosenTreeID);

                String res = RestApi.sqlCommand(updateTree);
                if (!res.trim().isEmpty())
                    Toast.makeText(this, "Something went wrong, try again later.", Toast.LENGTH_SHORT).show();

                Utils.importTrees();

                etType.setInputType(InputType.TYPE_NULL);
                etPrice.setInputType(InputType.TYPE_NULL);
                etUrl.setVisibility(View.GONE);
                btnSaveData.setVisibility(View.GONE);
                btnCancelSave.setVisibility(View.GONE);
                textInputLayout.setVisibility(View.VISIBLE);
                btnSeeMap.setVisibility(View.VISIBLE);
                btnPlant.setVisibility(View.VISIBLE);
                btnUpdateData.setVisibility(View.VISIBLE);

                etType.setText(tree.getType());
                etPrice.setText((tree.getPrice() + "₪"));
                etUrl.setText(Trees.chosenTree.getImageUrl());
                textInputLayout.setError("");
            }
        }

        if (btnSeeMap.isPressed() && !autoCompleteTextView.getText().toString().isEmpty()) {
            textInputLayout.setError("");
            ImageViewDialogBoxActivity imageViewDialogBoxActivity = new ImageViewDialogBoxActivity(this);
            imageViewDialogBoxActivity.show();
        }

        else if (btnPlant.isPressed() && !autoCompleteTextView.getText().toString().isEmpty()) {
            Intent intent = new Intent(this, PaymentForTreesActivity.class);
            startActivity(intent);
        }
        else {
            textInputLayout.setError("Please select an address");
        }

    }
}
