package com.example.sqlproject;

public class RestApi {

    static ServerPostCommunication serverPostCommunication = new ServerPostCommunication();


    public static String privateSqlCommand(String sqlCommand)
    {
        return  serverPostCommunication.doInBackground("function=privateSqlCommand", "sqlCommand="+sqlCommand);
    }


    public static String sqlCommand(String sqlCommand)
    {
        return  serverPostCommunication.doInBackground("function=sqlCommand", "sqlCommand="+sqlCommand);
    }

    public static String twoSqlCommand(String sqlCommand)
    {
        return  serverPostCommunication.doInBackground("function=twoSqlCommand", "sqlCommand="+sqlCommand);
    }

    public static String showFile(String path)
    {


        return  serverPostCommunication.doInBackground("function=showFile", "path="+path);
    }


    public static void saveFile(String path,String data)
    {

        serverPostCommunication.doInBackground("function=saveFile", "path="+path,"txt="+data);
    }


    public static void savePhoto(String photoText,String photoName)
    {

        serverPostCommunication.doInBackground("function=savePhoto", "photoText="+photoText,"photoName="+photoName );

    }

    public static String getCodeUpdate() {
        return serverPostCommunication.doInBackground("function=getCodeUpdate");
    }
}
