package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class TreesListActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {


    RecycleAdapterTrees.RecycleViewClickListener listener;

    public DrawerLayout drawerLayout;
    public NavigationView navigationView;
    public Toolbar toolbar;
    public RecycleAdapterTrees treeAdapter;

    Context context;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trees_list_activity);

        Trees.getTrees();

        context = this;

        drawerLayout = findViewById(R.id.drawerLayoutTreesList);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbarTreesList);
        setSupportActionBar(toolbar);

        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_new_tree_plant);

        initRecycleView();

        SearchView searchView = findViewById(R.id.searchViewTrees);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Handle search submission
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterTrees(newText);
                return false;
            }
        });
    }

    private void filterTrees(String query) {
        List<Tree> filteredTrees = new ArrayList<>();

        for (Tree tree : Trees.getTrees()) {
            if (tree.getType().toLowerCase().contains(query.toLowerCase())) {
                filteredTrees.add(tree);
            }
        }

        if (treeAdapter!= null) {
            treeAdapter.updateTrees(filteredTrees);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.nav_home){
            Intent intent = new Intent(TreesListActivity.this, HomeActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_new_tree_plant){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        if (menuItem.getItemId() == R.id.nav_planted_trees){
            if (Users.loggedOnUser.isAdmin()) {
                Intent intent = new Intent(TreesListActivity.this, PlantsHistoryAdminActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(TreesListActivity.this, PlantsHistoryUserActivity.class);
                startActivity(intent);
            }
        }
        if (menuItem.getItemId() == R.id.nav_account_center) {
            Intent intent = new Intent(TreesListActivity.this, InfoUpdateActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_log_out){
            LogoutDialogBoxActivity logoutDialogBoxActivity = new LogoutDialogBoxActivity(this);
            logoutDialogBoxActivity.show();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View view) {}

    void initRecycleView()
    {
        RecyclerView recycleView;
        recycleView = findViewById(R.id.rVadminPlant);

        itemClick();
        RecycleAdapterTrees adapter = new RecycleAdapterTrees(Trees.getTrees(),listener,this);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recycleView.setLayoutManager(layoutManager);
        recycleView.setItemAnimator(new DefaultItemAnimator());
        recycleView.setAdapter(adapter);

        itemClick();
        treeAdapter = new RecycleAdapterTrees(Trees.getTrees(), listener, this);
        RecyclerView.LayoutManager layoutManager2 = new LinearLayoutManager(getApplicationContext());
        recycleView.setLayoutManager(layoutManager2);
        recycleView.setItemAnimator(new DefaultItemAnimator());
        recycleView.setAdapter(treeAdapter);

    }


    void itemClick()
    {
        listener = new RecycleAdapterTrees.RecycleViewClickListener()
        {
            @Override
            public void onClick(View v, int position) {
                Tree chosenTree = Trees.getTrees().get(position);
                Intent intent = new Intent(context, TreeDataPreviewActivity.class);
                intent.putExtra("type",chosenTree.getType());
                Trees.setChosenTree(chosenTree);
                context.startActivity(intent);

              Toast.makeText(TreesListActivity.this, "this is check "+ position, Toast.LENGTH_SHORT).show();
            }
        };

//        listener2 = new RecycleAdapterTrees()
//        {
//            public void onClick(View v, int position) {
//                Tree chosenTree = Trees.getTrees().get(position);
//                Intent intent = new Intent(context, TreeDataPreviewActivity.class);
//                intent.putExtra("type",chosenTree.getType());
//                Trees.setChosenTree(chosenTree);
//                context.startActivity(intent);
//
////              Toast.makeText(TreePlantitgActivity.this, "this is check "+ position, Toast.LENGTH_SHORT).show();
//            }
//        };
    }
}