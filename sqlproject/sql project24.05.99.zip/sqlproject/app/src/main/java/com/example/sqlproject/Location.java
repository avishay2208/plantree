package com.example.sqlproject;

public class Location {
    private final int id;
    private final String address;
    private final String mapImageUrl;

    public Location(int id, String address, String mapImageUrl) {
        this.id = id;
        this.address = address;
        this.mapImageUrl = mapImageUrl;
    }

    public int getID() {
        return id;
    }

    public String getAddress() {
        return address;
    }

    public String getMapImageUrl() {
        return mapImageUrl;
    }
}