package com.example.sqlproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    EditText eTpasswordReg, eTconfirmPasswordReg, eTmailReg, eTphoneNumber, eTfirstNameReg, eTlastNameReg;
    Button btnRegReg;
    String firstName = "", lastName = "", phoneNumber = "", eMail = "", password = "", plantCount = "";
    boolean isAdmin = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_activity);

        Users.getUsers();

        initButtons();
        initEditTexts();
    }

    void initButtons() {
        btnRegReg = findViewById(R.id.btnRegReg);
        btnRegReg.setOnClickListener(this);
    }

    void initEditTexts() {
        eTpasswordReg = findViewById(R.id.eTpasswordReg);
        eTconfirmPasswordReg = findViewById(R.id.eTconfirmPasswordReg);
        eTmailReg = findViewById(R.id.eTeMailReg);
        eTphoneNumber = findViewById(R.id.eTphoneNumberReg);
        eTfirstNameReg = findViewById(R.id.eTfirstNameReg);
        eTlastNameReg = findViewById(R.id.eTlastNameReg);
    }

    @Override
    public void onClick(View view) {

        boolean valid = true;

        if (btnRegReg.isPressed()) {

//            if (eTfirstName.getText().toString().length() < 2) {
//                Toast.makeText(this, "First name is too short", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
//
//            if(eTlastName.getText().toString().length() < 2) {
//                Toast.makeText(this, "Last name is too short", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
//
//            if (!eTmailReg.getText().toString().contains("@") || !eTmailReg.getText().toString().contains(".com")) {
//                Toast.makeText(this, "Invalid eMail address", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
//
//            if (eTphoneNumber.getText().toString().length() != 10) {
//                Toast.makeText(this, "Invalid phone number", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
//
//            if (eTpasswordReg.getText().toString().length() < 3) {
//                Toast.makeText(this, "Password is too short", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
//
//            if (!eTpasswordReg.getText().toString().equals(eTconfirmPasswordReg.getText().toString())) {
//                Toast.makeText(this, "The passwords don't match", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
        }

        if (valid) {
            firstName = eTfirstNameReg.getText().toString();
            lastName = eTlastNameReg.getText().toString();
            phoneNumber = eTphoneNumber.getText().toString();
            eMail = eTmailReg.getText().toString();
            password = eTpasswordReg.getText().toString();
            plantCount = "0";

            Users users = Users.getUsers();
            String newUserId = String.valueOf(users.get(users.size() - 1).getID() + 1);

            User newUser = new User(Integer.parseInt(newUserId) ,firstName, lastName, phoneNumber, eMail, password, Integer.parseInt(plantCount), Utils.getCurrentDate(), isAdmin);

            if (Integer.parseInt(newUserId) == 0) {
                User.setAdmin(newUser);
            }

            String insertUser = String.format("INSERT INTO users (id, firstName, lastName, phoneNumber, eMail, password, plantCounter, joinDate, isAdmin) " +
                    "VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%b')  ",
                    newUser.getID(),
                    newUser.getFirstName(),
                    newUser.getLastName(),
                    newUser.getPhoneNumber(),
                    newUser.getEmail(),
                    newUser.getPassword(),
                    newUser.getPlantCounter(),
                    newUser.getJoinDate(),
                    newUser.isAdmin());

            String res = RestApi.sqlCommand(insertUser);

            if (!res.trim().isEmpty()) {
                Toast.makeText(this, "Email is already in use", Toast.LENGTH_SHORT).show();
            } else {
                Users.setLoggedOnUser(newUser);
                Intent intent = new Intent(RegisterActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        }
    }
}