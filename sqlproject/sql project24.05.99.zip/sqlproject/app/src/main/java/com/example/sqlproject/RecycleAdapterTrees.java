package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class RecycleAdapterTrees extends RecyclerView.Adapter<RecycleAdapterTrees.MyViewHolder> {

    private ArrayList<Tree> trees;
    private List<Tree> treeList;
    Context context;
    private RecycleViewClickListener listener;

    public RecycleAdapterTrees(ArrayList<Tree> trees, RecycleViewClickListener listener, Context context) {
        this.trees = trees;
        this.context = context;
        this.listener = listener;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void updateTrees(List<Tree> trees) {
        this.trees.clear();
        this.trees.addAll(trees);
        notifyDataSetChanged();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView tVType, tVPrice;
        private ImageView iVTree;

        public MyViewHolder(final View view) {
            super(view);
            tVType = view.findViewById(R.id.tVTreeType);
            tVPrice = view.findViewById(R.id.tVTreePrice);
            iVTree = view.findViewById(R.id.TreeIV);

            view.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            listener.onClick(view, getAdapterPosition());
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tree, parent, false);
        return new MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Tree tree = trees.get(position);

        holder.tVType.setText(tree.getType());
        holder.tVPrice.setText(tree.getPrice() + "₪");
        Picasso.get().load(tree.getImageUrl()).into(holder.iVTree);
    }


    @Override
    public int getItemCount() {
        return trees.size();
    }

    public interface RecycleViewClickListener {
        void onClick(View v, int position);
    }
}