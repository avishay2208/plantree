package com.example.sqlproject;

import java.util.ArrayList;

public class Users extends ArrayList<User> {

    private static Users users = new Users();
    public static User loggedOnUser;

    public static Users getUsers() {
        if (users.isEmpty())
            Utils.importUsers();

        return users;
    }

    public static User getLoggedOnUserByMail(String eMail) {
        return Users.getUsers().stream().filter(user -> user.getEmail().equals(eMail)).findAny().get();
    }

    public static void setLoggedOnUser(User user) {
        loggedOnUser = user;
    }

    public static void userLogout() {
        setLoggedOnUser(new User(0,"","","","","",0,"", false));
    }

    public static void setUsers(Users users) {
        Users.users = users;
    }
}
