package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InfoUpdateActivity extends AppCompatActivity implements View.OnClickListener{

    EditText eTfirstName, eTlastName, eTeMail, eTphoneNumber, eTpassword, eTconfirmPassword;
    Button btnSaveChanges, btnDeleteUser;
    String firstName = "", lastName = "", phoneNumber = "", eMail = "", password = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_update_activity);

        initButtons();
        initEditTexts();
    }

    void initButtons() {
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnDeleteUser = findViewById(R.id.btnDeleteUser);
        btnSaveChanges.setOnClickListener(this);
        btnDeleteUser.setOnClickListener(this);
    }

    void initEditTexts() {
        eTfirstName = findViewById(R.id.eTfirstNameUpdate);
        eTlastName = findViewById(R.id.eTlastNameUpdate);
        eTeMail = findViewById(R.id.eTeMailUpdate);
        eTphoneNumber = findViewById(R.id.eTphoneNumberUpdate);
        eTpassword = findViewById(R.id.eTpasswordUpdate);
        eTconfirmPassword = findViewById(R.id.eTconfirmPasswordUpdate);

        eTfirstName.setText(Users.loggedOnUser.getFirstName());
        eTlastName.setText(Users.loggedOnUser.getLastName());
        eTeMail.setText(Users.loggedOnUser.getEmail());
        eTphoneNumber.setText(Users.loggedOnUser.getPhoneNumber());
        eTpassword.setText(Users.loggedOnUser.getPassword());
        eTconfirmPassword.setText(Users.loggedOnUser.getPassword());
    }

    @Override
    public void onClick(View v) {
        boolean valid = true;

        if (btnSaveChanges.isPressed()) {
            if (!eTfirstName.getText().toString().isEmpty()) {
                if (eTfirstName.getText().toString().length() < 2) {
                    Toast.makeText(this, "First name is too short", Toast.LENGTH_SHORT).show();
                    valid = false;
                }
            }
            if (!eTlastName.getText().toString().isEmpty()) {
                if (eTlastName.getText().toString().length() < 2) {
                    Toast.makeText(this, "Last name is too short", Toast.LENGTH_SHORT).show();
                    valid = false;
                }
            }
            if (!eTeMail.getText().toString().isEmpty()) {
                if (!eTeMail.getText().toString().contains("@") && !eTeMail.getText().toString().contains(".com")) {
                    Toast.makeText(this, "Invalid eMail address", Toast.LENGTH_SHORT).show();
                    valid = false;
                }
            }
            if (!eTphoneNumber.getText().toString().isEmpty()) {
                if (eTphoneNumber.getText().toString().length() != 10) {
                    Toast.makeText(this, "Invalid phone number", Toast.LENGTH_SHORT).show();
                    valid = false;
                }
            }
            if (!eTpassword.getText().toString().isEmpty() || !eTconfirmPassword.getText().toString().isEmpty()) {
                if (eTpassword.getText().toString().length() < 3) {
                    Toast.makeText(this, "Password is too short", Toast.LENGTH_SHORT).show();
                    if (!eTpassword.getText().toString().equals(eTconfirmPassword.getText().toString()))
                        Toast.makeText(this, "The passwords don't match", Toast.LENGTH_SHORT).show();
                    valid = false;
                }
            }
        }

        if (btnDeleteUser.isPressed()) {

            //dialogBox

            @SuppressLint("DefaultLocale")
            String deleteUser = String.format("DELETE FROM users WHERE id = %d ", Users.loggedOnUser.getID());
            RestApi.sqlCommand(deleteUser);
            Users.userLogout();
        }

        if (valid) {
            firstName = eTfirstName.getText().toString();
            lastName = eTlastName.getText().toString();
            phoneNumber = eTphoneNumber.getText().toString();
            eMail = eTeMail.getText().toString();
            password = eTpassword.getText().toString();
            int loggedOnUserID = Users.loggedOnUser.getID();

            @SuppressLint("DefaultLocale")
            String updateUser = String.format("UPDATE users SET " +
                            "firstName = COALESCE('%s', firstName)," +
                            "lastName = COALESCE('%s', lastName)," +
                            "phoneNumber = COALESCE('%s', phoneNumber)," +
                            "eMail = COALESCE('%s', eMail)," +
                            "password = COALESCE('%s', password) " +
                            "WHERE id = %d",
                    firstName, lastName, phoneNumber, eMail, password, loggedOnUserID);
            String res = RestApi.sqlCommand(updateUser);

            if (!res.trim().isEmpty()) {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Info was changed successfully", Toast.LENGTH_SHORT).show();
                User updatedUser = new User(firstName, lastName, phoneNumber, eMail, password);
                Users.setLoggedOnUser(updatedUser);
            }
        }
    }
}