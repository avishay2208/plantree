package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RecycleAdapterPlantsAdmin extends RecyclerView.Adapter<RecycleAdapterPlantsAdmin.MyViewHolder> {
    private final ArrayList<Plant> plants;
    private final ArrayList<Tree> trees;
    Context context;
    private final RecycleAdapterPlantsAdmin.RecycleViewClickListener listener;

    public RecycleAdapterPlantsAdmin(ArrayList<Plant> plants, ArrayList<Tree> trees, RecycleAdapterPlantsAdmin.RecycleViewClickListener listener, Context context) {
        this.plants = plants;
        this.trees = trees;
        this.context = context;
        this.listener = listener;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        /* 1 */
        private final TextView tVplantID;
        private final TextView tVtreeType;
        private final TextView tVtreeID;
        private final TextView tVuserName;
        private final TextView tVuserID;
        private final TextView tVplantDate;
        private final TextView tVplantAddress;
        private final TextView tVprice;
        private final ImageView iVtree;

        public MyViewHolder(final View view) {
            super(view);

            /* 2 */
            tVplantID = view.findViewById(R.id.tvADMINplantID);
            tVtreeType = view.findViewById(R.id.tvADMINplantTreeType);
            tVtreeID = view.findViewById(R.id.tvADMINplantTreeID);
            tVuserName = view.findViewById(R.id.tvADMINplantUserName);
            tVuserID = view.findViewById(R.id.tvADMINplantUserID);
            tVplantDate = view.findViewById(R.id.tvADMINplantDate);
            tVplantAddress = view.findViewById(R.id.tvADMINplantAddress);
            tVprice = view.findViewById(R.id.tvADMINplantPrice);
            iVtree = view.findViewById(R.id.ivADMINplantTree);

            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            listener.onClick(view, getAdapterPosition());
        }
    }

    @NonNull
    @Override
    public RecycleAdapterPlantsAdmin.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_plant_admin, parent, false);
        return new RecycleAdapterPlantsAdmin.MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecycleAdapterPlantsAdmin.MyViewHolder holder, int position) {
        Plant plant = plants.get(position);
        Tree tree = trees.get(plant.getTreeID() - 1);

        holder.tVplantID.setText("Plant ID: " + plant.getPlantID());
        holder.tVtreeType.setText(plant.getTreeName() + " tree");
        holder.tVtreeID.setText("Tree ID: " + plant.getTreeID());
        holder.tVuserName.setText("By: " + plant.getUserName());
        holder.tVuserID.setText("User ID: " + plant.getUserID());
        holder.tVplantDate.setText(String.valueOf(plant.getPlantDate()));
        holder.tVplantAddress.setText("At: " + plant.getPlantAddress());
        holder.tVprice.setText(plant.getPrice() + "₪");
        Picasso.get().load(tree.getImageUrl()).into(holder.iVtree);
    }

    @Override
    public int getItemCount() {
        return plants.size();
    }

    public interface RecycleViewClickListener {
        void onClick(View v, int position);
    }
}