package com.example.sqlproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AddressArrayAdapter extends ArrayAdapter<Location> {

    public AddressArrayAdapter(Context context, List<Location> locations) {
        super(context, 0, locations);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Location location = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_drop_down, parent, false);
        }
        TextView addressView = (TextView) convertView.findViewById(R.id.addressText);
        addressView.setText(location.getAddress());
        return convertView;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                List<Location> originalList = new ArrayList<>(Locations.getLocations());
                List<Location> filteredList = new ArrayList<>();

                if (constraint == null || constraint.length() == 0) {
                    results.values = originalList;
                    results.count = originalList.size();
                } else {
                    String filterPattern = constraint.toString().toLowerCase().trim();
                    for (Location location : originalList) {
                        if (location.getAddress().toLowerCase().contains(filterPattern)) {
                            filteredList.add(location);
                        }
                    }
                    results.values = filteredList;
                    results.count = filteredList.size();
                }
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                notifyDataSetChanged(); // Notify the attached observers that the underlying data has been changed and any View reflecting the data set should refresh itself.
            }
        };
    }
}
