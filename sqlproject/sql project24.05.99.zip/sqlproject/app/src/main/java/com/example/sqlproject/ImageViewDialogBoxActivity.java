package com.example.sqlproject;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.squareup.picasso.Picasso;

import java.util.Objects;

public class ImageViewDialogBoxActivity extends Dialog implements View.OnClickListener {

    Button btnDialogClose;
    ImageView iv;
    Context context;

    public ImageViewDialogBoxActivity(@NonNull Context context) {
        super(context);
        this.context = context;

        Objects.requireNonNull(this.getWindow()).setBackgroundDrawableResource(R.drawable.dialog_bg);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_view_dialog_box);
        initButtons();
        initImageViews();
    }

    void initButtons() {
        btnDialogClose = findViewById(R.id.btnClose);
        btnDialogClose.setOnClickListener(this);
    }

    void initImageViews() {
        iv = findViewById(R.id.imageView3);
        Picasso.get().load(Locations.chosenLocation.getMapImageUrl()).into(iv);
    }

    @Override
    public void onClick(View v) {
        if (btnDialogClose.isPressed())
            dismiss();
    }
}
