package com.example.sqlproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSignIn, btnSignUp;
    String loggedEmail;
    EditText eTeMail, eTpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initButtons();
        initEditTexts();
    }

    void initButtons() {
        btnSignIn = findViewById(R.id.btnSignIn);
        btnSignUp = findViewById(R.id.btnSignUp);

        btnSignIn.setOnClickListener(this);
        btnSignUp.setOnClickListener(this);
    }

    void initEditTexts() {
        eTeMail = findViewById(R.id.eTeMailSignIn);
        eTpassword = findViewById(R.id.eTpasswordSignIn);
    }

    @Override
    public void onClick(View view) {
        if (btnSignIn.isPressed()) {
            Users.getUsers();

            loggedEmail = eTeMail.getText().toString();
            User loggedOnUser = Users.getLoggedOnUserByMail(loggedEmail);

            if (loggedOnUser != null && eTpassword.getText().toString().equals(loggedOnUser.getPassword())) {
                Users.setLoggedOnUser(loggedOnUser);
                Toast.makeText(this, "Signed in successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, HomeActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show();
            }
        }
        if (btnSignUp.isPressed()) {
            Intent intent2 = new Intent(this, RegisterActivity.class);
            startActivity(intent2);
        }
    }
}