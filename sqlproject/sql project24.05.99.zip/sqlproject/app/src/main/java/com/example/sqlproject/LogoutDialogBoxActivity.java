package com.example.sqlproject;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.Objects;

public class LogoutDialogBoxActivity extends Dialog implements View.OnClickListener {

    Button btnDialogLogout, btnDialogCancel;
    Context context;
    public LogoutDialogBoxActivity(@NonNull Context context) {
        super(context);
        this.context = context;

        Objects.requireNonNull(this.getWindow()).setBackgroundDrawableResource(R.drawable.dialog_bg);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logout_dialog_box);
        initButtons();

    }

    void initButtons() {
        btnDialogLogout = findViewById(R.id.btnDialogLogout);
        btnDialogCancel = findViewById(R.id.btnDialogCancel);

        btnDialogLogout.setOnClickListener(this);
        btnDialogCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (btnDialogLogout.isPressed()) {
            Users.userLogout();
            Toast.makeText(context, "Logged out successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(context, MainActivity.class);
            context.startActivity(intent);
            dismiss();
        }
        else
            dismiss();
    }
}
