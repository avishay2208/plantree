package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputLayout;

import java.util.List;

public class ManageTreesActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener ,View.OnClickListener {


    Context context;
    Tree tree;
    Button btnAddTree, btnEditTree, btnDeleteTree, btnSaveTree, btnCancelSave;
    EditText etAddTreeType, etAddTreePrice, etAddTreeImageUrl;
    TextInputLayout textInputLayout;
    AutoCompleteTextView autoCompleteTextView;
    String treeType, treeImageUrl;
    double treePrice;
    boolean valid = true;
    public DrawerLayout drawerLayout;
    public NavigationView navigationView;
    public Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manage_trees_activity);

        context = this;

        drawerLayout = findViewById(R.id.drawerLayoutAdminTreesManagement);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbarAdminTreesManagement);
        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        initButtons();
        initEditTexts();
        initTextInput();
    }

    void initButtons() {
        btnAddTree = findViewById(R.id.btnAddTree);
        btnEditTree = findViewById(R.id.btnEditTree);
        btnDeleteTree = findViewById(R.id.btnDeleteTree);
        btnSaveTree = findViewById(R.id.btnSaveNewTree);
        btnCancelSave = findViewById(R.id.btnCancelSaveNewTree);
        btnAddTree.setOnClickListener(this);
        btnEditTree.setOnClickListener(this);
        btnDeleteTree.setOnClickListener(this);
        btnSaveTree.setOnClickListener(this);
        btnCancelSave.setOnClickListener(this);

        btnSaveTree.setVisibility(View.GONE);
        btnCancelSave.setVisibility(View.GONE);
    }

    void initEditTexts() {
        etAddTreeType = findViewById(R.id.etAddTreeType);
        etAddTreePrice = findViewById(R.id.etAddTreePrice);
        etAddTreeImageUrl = findViewById(R.id.etAddTreeImageUrl);

        etAddTreeType.setVisibility(View.GONE);
        etAddTreePrice.setVisibility(View.GONE);
        etAddTreeImageUrl.setVisibility(View.GONE);
    }

    void initTextInput() {
        textInputLayout = findViewById(R.id.inputLayoutManageTrees);
        autoCompleteTextView = findViewById(R.id.inputTVmanageTrees);
        Utils.importTrees();
        List<String> trees = Trees.getTreeTypesOnly();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_drop_down, trees);
        autoCompleteTextView.setAdapter(adapter);
        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Trees.setChosenTree(Trees.getTreeByType((trees.get(position))));
                textInputLayout.setError("");
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.nav_home){
            Intent intent = new Intent(ManageTreesActivity.this, HomeActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_new_tree_plant) {
            Intent intent = new Intent(ManageTreesActivity.this, TreesListActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_planted_trees) {
            if (Users.loggedOnUser.isAdmin()) {
                Intent intent = new Intent(ManageTreesActivity.this, PlantsHistoryAdminActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(ManageTreesActivity.this, PlantsHistoryUserActivity.class);
                startActivity(intent);
            }
        }
        if (menuItem.getItemId() == R.id.nav_account_center) {
            Intent intent = new Intent(ManageTreesActivity.this, InfoUpdateActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_log_out){
            LogoutDialogBoxActivity logoutDialogBoxActivity = new LogoutDialogBoxActivity(this);
            logoutDialogBoxActivity.show();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    public void onClick(View v) {
        textInputLayout.setError("");
        if (btnEditTree.isPressed() && !autoCompleteTextView.getText().toString().isEmpty()) {
            Intent intent = new Intent(context, TreeDataPreviewActivity.class);
            intent.putExtra("type",Trees.chosenTree.getType());
            context.startActivity(intent);
        }
        else
            textInputLayout.setError("Please select a tree");

        if (btnDeleteTree.isPressed()) {
            @SuppressLint("DefaultLocale")
            String deleteTree = String.format("DELETE FROM trees WHERE id = %d ", Trees.chosenTree.getID());
            String res = RestApi.sqlCommand(deleteTree);
            autoCompleteTextView.setText("");
            initTextInput();
            Toast.makeText(context, "Tree deleted successfully", Toast.LENGTH_SHORT).show();
        }

        if (btnAddTree.isPressed()) {
            textInputLayout.setVisibility(View.GONE);
            autoCompleteTextView.setVisibility(View.GONE);
            btnEditTree.setVisibility(View.GONE);
            btnDeleteTree.setVisibility(View.GONE);
            btnAddTree.setVisibility(View.GONE);

            etAddTreeType.setVisibility(View.VISIBLE);
            etAddTreePrice.setVisibility(View.VISIBLE);
            etAddTreeImageUrl.setVisibility(View.VISIBLE);
            btnSaveTree.setVisibility(View.VISIBLE);
            btnCancelSave.setVisibility(View.VISIBLE);
        }

        if (btnSaveTree.isPressed()) {
            if (etAddTreeType.getText().toString().isEmpty()) {
                etAddTreeType.setError("Invalid Type");
                valid = false;
            }
            if (etAddTreePrice.getText().toString().isEmpty() || etAddTreePrice.getText().toString().contains("₪")) {
                etAddTreePrice.setError("Invalid Price");
                valid = false;
            }
            if (etAddTreeImageUrl.getText().toString().isEmpty()) {
                etAddTreeImageUrl.setError("Invalid URL");
                valid = false;
            }

            treeType = etAddTreeType.getText().toString();
            treePrice = Double.parseDouble(etAddTreePrice.getText().toString());
            treeImageUrl = etAddTreeImageUrl.getText().toString();

            if (valid) {
                Trees trees = Trees.getTrees();
                String newTreeId = String.valueOf(trees.get(trees.size() - 1).getID() + 1);
                Tree newTree = new Tree(Integer.parseInt(newTreeId), treeType, treePrice, treeImageUrl);

                @SuppressLint("DefaultLocale")
                String insertTree = String.format("INSERT INTO trees (id, type, price, imageUrl) " +
                                "VALUES ('%s', '%s', %f, '%s')  ",
                        newTree.getID(),
                        newTree.getType(),
                        newTree.getPrice(),
                        newTree.getImageUrl());

                String res = RestApi.sqlCommand(insertTree);
                if (!res.trim().isEmpty())
                    Toast.makeText(this, "Something went wrong, try again later.", Toast.LENGTH_SHORT).show();

                initTextInput();
            }
        }

        if (btnCancelSave.isPressed()) {
            etAddTreeType.setVisibility(View.GONE);
            etAddTreePrice.setVisibility(View.GONE);
            etAddTreeImageUrl.setVisibility(View.GONE);
            btnSaveTree.setVisibility(View.GONE);
            btnCancelSave.setVisibility(View.GONE);

            btnAddTree.setVisibility(View.VISIBLE);
            textInputLayout.setVisibility(View.VISIBLE);
            autoCompleteTextView.setVisibility(View.VISIBLE);
            btnEditTree.setVisibility(View.VISIBLE);
            btnDeleteTree.setVisibility(View.VISIBLE);
        }
    }
}
