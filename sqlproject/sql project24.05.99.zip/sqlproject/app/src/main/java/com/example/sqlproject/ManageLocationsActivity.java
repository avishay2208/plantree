package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputLayout;

import java.util.List;

public class ManageLocationsActivity  extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener , View.OnClickListener {

    Context context;
    Location location;
    Button btnAddLocation, btnEditLocation, btnDeleteLocation, btnSaveLocation, btnCancelSave, btnSaveNewLocation;
    EditText etLocationAddress, etLocationImageUrl;
    TextInputLayout textInputLayout;
    AutoCompleteTextView autoCompleteTextView;
    String locationAddress, locationImageUrl;

    boolean validNew = true, validUpdate = true;
    public DrawerLayout drawerLayout;
    public NavigationView navigationView;
    public Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manage_locations_activity);

        context = this;

        drawerLayout = findViewById(R.id.drawerLayoutAdminLocationsManagement);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbarAdminLocationsManagement);
        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        initButtons();
        initEditTexts();
        initTextInput();
    }

    void initButtons() {
        //btnAddLocation = findViewById(R.id.btnAddTree);
        btnEditLocation = findViewById(R.id.btnEditManageLocations);
        btnDeleteLocation = findViewById(R.id.btnDeleteManageLocations);
        btnSaveLocation = findViewById(R.id.btnSaveChangesManageLocations);
        btnCancelSave = findViewById(R.id.btnCancelChangesManageLocations);
        //btnAddLocation.setOnClickListener(this);
        btnEditLocation.setOnClickListener(this);
        btnDeleteLocation.setOnClickListener(this);
        btnSaveLocation.setOnClickListener(this);
        btnCancelSave.setOnClickListener(this);

        btnSaveLocation.setVisibility(View.GONE);
        btnCancelSave.setVisibility(View.GONE);
    }

    void initEditTexts() {
        etLocationAddress = findViewById(R.id.etChangeAddress);
        etLocationImageUrl = findViewById(R.id.etChangeImageUrlLocations);

        etLocationAddress.setVisibility(View.GONE);
        etLocationImageUrl.setVisibility(View.GONE);
    }

    void initTextInput() {
        textInputLayout = findViewById(R.id.inputLayoutManageLocations);
        autoCompleteTextView = findViewById(R.id.inputTVManageLocations);
        Utils.importLocations();
        List<String> addresses = Locations.getAddressesOnly();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_drop_down, addresses);
        autoCompleteTextView.setAdapter(adapter);
        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Locations.setChosenLocation(Locations.getLocationByAddress(addresses.get(position)));
                textInputLayout.setError("");
                etLocationAddress.setText(Locations.chosenLocation.getAddress());
                etLocationImageUrl.setText(Locations.chosenLocation.getMapImageUrl());
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.nav_home){
            Intent intent = new Intent(ManageLocationsActivity.this, HomeActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_new_tree_plant) {
            Intent intent = new Intent(ManageLocationsActivity.this, TreesListActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_planted_trees) {
            if (Users.loggedOnUser.isAdmin()) {
                Intent intent = new Intent(ManageLocationsActivity.this, PlantsHistoryAdminActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(ManageLocationsActivity.this, PlantsHistoryUserActivity.class);
                startActivity(intent);
            }
        }
        if (menuItem.getItemId() == R.id.nav_account_center) {
            Intent intent = new Intent(ManageLocationsActivity.this, InfoUpdateActivity.class);
            startActivity(intent);
        }
        if (menuItem.getItemId() == R.id.nav_log_out){
            LogoutDialogBoxActivity logoutDialogBoxActivity = new LogoutDialogBoxActivity(this);
            logoutDialogBoxActivity.show();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    public void onClick(View v) {
        textInputLayout.setError("");
        if (btnEditLocation.isPressed() && !autoCompleteTextView.getText().toString().isEmpty()) {
            textInputLayout.setVisibility(View.GONE);
            autoCompleteTextView.setVisibility(View.GONE);
            btnEditLocation.setVisibility(View.GONE);
            btnDeleteLocation.setVisibility(View.GONE);
            btnCancelSave.setVisibility(View.VISIBLE);
            btnSaveLocation.setVisibility(View.VISIBLE);
            etLocationAddress.setVisibility(View.VISIBLE);
            etLocationImageUrl.setVisibility(View.VISIBLE);
        }
        else
            textInputLayout.setError("Please select an address");

        if (btnDeleteLocation.isPressed()) {
            @SuppressLint("DefaultLocale")
            String deleteLocation = String.format("DELETE FROM locations WHERE id = %d ", Locations.chosenLocation.getID());
            RestApi.sqlCommand(deleteLocation);
            autoCompleteTextView.setText("");
            initTextInput();
            Toast.makeText(context, "Location deleted successfully", Toast.LENGTH_SHORT).show();
        }

//        if (btnAddLocation.isPressed()) {
//            textInputLayout.setVisibility(View.GONE);
//            autoCompleteTextView.setVisibility(View.GONE);
//            btnEditTree.setVisibility(View.GONE);
//            btnDeleteTree.setVisibility(View.GONE);
//            btnAddTree.setVisibility(View.GONE);
//
//            etAddTreeType.setVisibility(View.VISIBLE);
//            etAddTreePrice.setVisibility(View.VISIBLE);
//            etAddTreeImageUrl.setVisibility(View.VISIBLE);
//            btnSaveTree.setVisibility(View.VISIBLE);
//            btnCancelSave.setVisibility(View.VISIBLE);
//        }

//        if (btnSaveNewLocation.isPressed()) {
//            if (etLocationAddress.getText().toString().isEmpty()) {
//                etLocationAddress.setError("Invalid Type");
//                validNew = false;
//            }
//            if (etLocationImageUrl.getText().toString().isEmpty()) {
//                etLocationImageUrl.setError("Invalid URL");
//                validNew = false;
//            }
//
//            locationAddress = etLocationAddress.getText().toString();
//            locationImageUrl = etLocationImageUrl.getText().toString();
//
//            if (validNew) {
//                Locations locations = Locations.getLocations();
//                String newLocationId = String.valueOf(locations.get(locations.size() - 1).getID() + 1);
//                Location newLocation = new Location(Integer.parseInt(newLocationId), locationAddress, locationImageUrl);
//
//                @SuppressLint("DefaultLocale")
//                String insertLocation = String.format("INSERT INTO locations (id, address, mapImageUrl) " +
//                                "VALUES ('%s', '%s', '%s')  ",
//                        newLocation.getID(),
//                        newLocation.getAddress(),
//                        newLocation.getMapImageUrl());
//
//                String resNew = RestApi.sqlCommand(insertLocation);
//                if (!resNew.trim().isEmpty())
//                    Toast.makeText(this, "Something went wrong, try again later.", Toast.LENGTH_SHORT).show();
//
//                initTextInput();
//            }
//        }

        if (btnSaveLocation.isPressed()) {
            if (etLocationAddress.getText().toString().isEmpty()) {
                etLocationAddress.setError("Invalid Type");
                validUpdate = false;
            }
            if (etLocationImageUrl.getText().toString().isEmpty()) {
                etLocationImageUrl.setError("Invalid URL");
                validUpdate = false;
            }
            if (validUpdate) {
                locationAddress = etLocationAddress.getText().toString();
                locationImageUrl = etLocationImageUrl.getText().toString();
                @SuppressLint("DefaultLocale")
                String updateUserPlantsCounter = String.format("UPDATE locations SET address = '%s', mapImageUrl = '%s' WHERE id = %d", locationAddress, locationImageUrl, Locations.chosenLocation.getID());
                String resUpdate = RestApi.sqlCommand(updateUserPlantsCounter);
                if (!resUpdate.trim().isEmpty())
                    Toast.makeText(this, "Something went wrong, try again later.", Toast.LENGTH_SHORT).show();
                else {
                    Toast.makeText(context, "Location updated successfully", Toast.LENGTH_SHORT).show();
                }
                initTextInput();
                //visibility visible;
            }
        }

        if (btnCancelSave.isPressed()) {
            etLocationAddress.setVisibility(View.GONE);
            etLocationImageUrl.setVisibility(View.GONE);
            btnSaveLocation.setVisibility(View.GONE);
            btnCancelSave.setVisibility(View.GONE);

            //btnAddNewLocation.setVisibility(View.VISIBLE);
            textInputLayout.setVisibility(View.VISIBLE);
            autoCompleteTextView.setVisibility(View.VISIBLE);
            btnEditLocation.setVisibility(View.VISIBLE);
            btnDeleteLocation.setVisibility(View.VISIBLE);
        }
    }
}
