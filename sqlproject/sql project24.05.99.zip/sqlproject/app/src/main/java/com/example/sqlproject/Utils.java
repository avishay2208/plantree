package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {
    public static void importUsers() {
        String jsonUser = RestApi.sqlCommand("select * from users");
        Log.e("my json", jsonUser);
        Users.setUsers(Serialization.convertStringJsonToObject(Users.class, jsonUser));
    }

    public static void importPlants() {
        String jsonPlant = RestApi.sqlCommand("select * from plants");
        Log.e("my json", jsonPlant);
        Plants.setPlants(Serialization.convertStringJsonToObject(Plants.class, jsonPlant));
    }

    public static void importPlantsByUserID(int userID) {
        @SuppressLint("DefaultLocale")
        String jsonPlantByUserID = RestApi.sqlCommand(String.format("select * from plants where userID = '%s'", userID));
        Log.e("my json", jsonPlantByUserID);
        Plants.setPlants(Serialization.convertStringJsonToObject(Plants.class, jsonPlantByUserID));
    }


    public static void importTrees() {
        String jsonTree = RestApi.sqlCommand("select * from trees");
        Log.e("my json", jsonTree);
        Trees.setTrees(Serialization.convertStringJsonToObject(Trees.class, jsonTree));
    }

    public static void importLocations() {
        String jsonLocation = RestApi.sqlCommand("select * from locations");
        Log.e("my json", jsonLocation);
        Locations.setLocations(Serialization.convertStringJsonToObject(Locations.class, jsonLocation));
    }

    public static String getCurrentDate() {
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        return dateFormat.format(new Date());
    }
}
