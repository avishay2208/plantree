package com.example.sqlproject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PaymentForTreesActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tVcardHolderID, tVcardNumber, tVcardDate, tVcardCVV;
    EditText eTcardHolderID, eTcardNumber, eTcardDate, eTcardCVV;
    Button btnPay;

    Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_for_planting_trees_activity);

        activity = this;

        initEditTexts();
        initTextViews();
        initButtons();
    }

    void initEditTexts() {
        eTcardHolderID = findViewById(R.id.eTcardID);
        eTcardNumber = findViewById(R.id.eTcardNumber);
        eTcardDate = findViewById(R.id.eTcardDate);
        eTcardCVV = findViewById(R.id.eTcardCVV);
    }

    void initTextViews() {
        tVcardHolderID = findViewById(R.id.tVcardID);
        tVcardNumber = findViewById(R.id.tVcardNumber);
        tVcardDate = findViewById(R.id.tVcardDate);
        tVcardCVV = findViewById(R.id.tVcardCVV);
    }

    void initButtons() {
        btnPay = findViewById(R.id.btnPay);
        btnPay.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {

        boolean valid = true;

        if (btnPay.isPressed()) {
//            if (eTcardHolderID.getText().toString().length() != 9) {
//                Toast.makeText(this, "Incorrect ID", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
//            if (eTcardNumber.getText().toString().length() != 16) {
//                Toast.makeText(this, "Incorrect card number", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
//            if (eTcardDate.getText().toString().length() != 5) {
//                Toast.makeText(this, "Incorrect Date", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
//            if (eTcardCVV.getText().toString().length() != 3) {
//                Toast.makeText(this, "Incorrect CVV", Toast.LENGTH_SHORT).show();
//                valid = false;
//            }
        }

        if(valid) {
            int updatedUserPlantCounter = Users.loggedOnUser.getPlantCounter() + 1;
            @SuppressLint("DefaultLocale")
            String updateUserPlantsCounter = String.format("UPDATE users SET plantCounter = %d WHERE id = %d", updatedUserPlantCounter, Users.loggedOnUser.getID());
            RestApi.sqlCommand(updateUserPlantsCounter);

            Users.loggedOnUser.setPlantCounter(updatedUserPlantCounter);

            Plants plants = Plants.getPlants();
            String newPlantID = plants.isEmpty() ? "1" : String.valueOf(plants.get(plants.size() - 1).getPlantID() + 1);

            @SuppressLint("DefaultLocale")
            String insertPlant = String.format("INSERT INTO plants (plantID, userID, userName, treeID, treeName, plantAddress, plantDate, price) " +
                    "VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f')",
                    newPlantID,
                    Users.loggedOnUser.getID(),
                    Users.loggedOnUser.getFullName(),
                    Trees.chosenTree.getID(),
                    Trees.chosenTree.getType(),
                    Locations.chosenLocation.getAddress(),
                    Utils.getCurrentDate(),
                    Trees.chosenTree.getPrice());

            RestApi.sqlCommand(insertPlant);

            PurchaseDialogBoxActivity purchaseDialogBoxActivity = new PurchaseDialogBoxActivity(this);
            purchaseDialogBoxActivity.show();
            SendSms.sendSMS("Plantree","Thank you for your purchase!\n",activity);

        }
    }
}
